# Start Here

## Welcome

Think of this folder as the hub for everything you do with your AI. It starts as notes and folders, but it can grow into whatever you need, including things you haven't thought of yet.

This folder is the start of your own AI thinking partner. It can be a business partner, a creative partner and a thinking partner, all in one place. It is a foundation, not a finished product. It grows with you as you use it.

## How it works

Claude lives in this folder. Every conversation can leave notes behind, and those notes are plain text files. Over time they become Claude's knowledge base about your work. You can open and read any of them in Obsidian (a free app for reading notes) or any text editor.

Links between notes do the organizing. A basecamp is a hub note in `Map/` for one topic, and it links to everything under that topic. Claude reads the basecamp first, so it finds things fast.

## Your first message

In Claude Cowork, type this:

`Read CLAUDE.md in this folder and follow it.`

In Claude Code, `hi` works too.

This folder is written for Claude. Other AI apps that can work in a folder on your computer, like ChatGPT's desktop app, should work too, since the notes and instructions are plain text files. Start the same way: Read CLAUDE.md in this folder and follow it. A guide for other apps is in the works.

## Who fills this folder

You talk, Claude writes. New notes and folders come from your conversations: Claude writes the daily note, makes your first basecamps, suggests more and links each new note to the right one. You rarely need to make, name or move a file yourself. The one exception is `Downloads/`, where you drop files you want Claude to read.

You can still open, edit or delete any note. Claude reads the new version next time.

## What's here

**Folders.** Each one has an About note inside that says what goes in it.

- `Map/` holds your basecamps, one note per topic. Claude makes the first ones during onboarding.
- `Calendar/` holds your daily notes, one per day: what you worked on and what's still open. Claude writes them as you chat and when you save a session.
- `Downloads/` holds files you bring in, like PDFs, transcripts and screenshots. It's the one folder you fill yourself.
- `Templates/` holds the starting shape for a new basecamp and a new daily note.

**Notes in the main folder.** Claude keeps these up to date as you work. The notes it makes for you land here too, linked from a basecamp.

- `CLAUDE.md` holds Claude's instructions and what it knows about you.
- `Current Context.md` is a whiteboard of what is active right now.
- `Lessons Log.md` records corrections, so Claude learns from them.
- `Voice Log.md` holds samples of how you write.
- `Connections.md` lists the apps Claude can reach.

**Setup files you can leave alone.**

- `README.md` and the two `Setup Guide` files explain how to set up the folder.
- `AGENTS.md` and `GEMINI.md` point other AI tools to `CLAUDE.md`.
- `setup/` holds the settings for Claude Code's reminders, one for Mac and one for Windows. The setup guide copies the right one for you.
- `.claude/` holds the skills: the playbooks Claude follows for one job each. Obsidian hides it. On Windows, File Explorer shows it.
- `.obsidian/` appears after you open the folder in Obsidian. It holds Obsidian's settings.

## Go slow

You do not need all of this on day one. The setup guide adds one habit a day, so you can start small and let it build.
