## Compass

Each time you correct Claude, the learn skill adds a row here. When a tag appears twice, Claude proposes a fixed rule and waits for your yes.

| Date | Tag | Strike | What happened | Fix | Status |
|---|---|---|---|---|---|
