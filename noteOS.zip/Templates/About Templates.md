# About Templates

This folder holds the starting shape for new notes. When Claude makes a new basecamp or a new daily note, it starts from the matching file here, so they all look the same.

- `Basecamp.md` is the shape of a basecamp: Compass, Notes and Trails.
- `Daily Note.md` is the shape of a daily note: TODO, Work, Personal and Recap.

You can change either one. Add a section you want in every daily note, and new daily notes start with it. Notes that already exist stay as they are.
