## Compass

<!-- One or two sentences: what is this topic, and why does it matter to you? -->

<!-- Links to the closest related notes or basecamps. -->

## Notes

<!-- Short list of what lives under this topic right now: open questions, current status, key dates. -->

## Trails

<!-- The notes worth visiting from here. Every link earns its place. Use [[Note Name|readable text]]. -->
