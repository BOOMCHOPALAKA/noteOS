# {{date}}

## TODO

**From today's meetings:**

**Carried from the last note:**

<!-- Only items you own. Use "Check:" at the start of a line for work you are waiting on from someone else. -->

## Work

<!-- Newest entry at the top. Give each meeting or work block its own ### heading. -->

## Personal

<!-- Newest entry at the top. -->

## Recap

<!-- Leave empty unless you ask for it. -->
