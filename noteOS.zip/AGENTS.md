This folder's instructions live in CLAUDE.md. Read that file first and follow it. Skills are playbooks in `.claude/skills/`; to run one, open its SKILL.md and do what it says.
