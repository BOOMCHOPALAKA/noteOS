# noteOS Starter

This folder is a ready-made notebook that you and Claude share. You read and write notes in it with Obsidian, and Claude reads the same notes, keeps them current and learns how you like to work. Over a few days, Claude starts to remember your work, so you don't have to explain it again each session.

This folder is written for Claude. Other AI apps that can work in a folder on your computer, like ChatGPT's desktop app, should work too, since the notes and instructions are plain text files. Start the same way: Read CLAUDE.md in this folder and follow it. A guide for other apps is in the works.

## Who it's for

You use an AI chat most days and want it to remember your work. You don't need a technical background. The setup guide walks you through every click.

## Start here

Open the guide for your computer and follow it from the top:

- **Mac:** `Setup Guide - Mac.md`
- **Windows:** `Setup Guide - Windows.md`

Day 1 takes about 30 to 45 minutes (a rough guess, mostly downloads and onboarding). Each day after that takes a few minutes.

## Where it works

The guides use **Cowork**, the part of the Claude desktop app where Claude works in a folder you pick. Cowork needs a paid plan (Pro, Max, Ultra, Team or Enterprise). Cowork sessions run in the cloud, so the files Claude uses are processed on Anthropic's servers. Keep private files out of this folder. Cowork doesn't read the instruction file on its own, so start a session with this first message:

`Read CLAUDE.md in this folder and follow it.`

The **Code tab** in the same app is optional. It reads the instruction file without being asked, starts skills on its own, runs two reminders and can split planning between two models. The guides cover it near the end.

## What's inside

- `Start Here.md` is a one-page map of the folder.
- `CLAUDE.md` is the instruction file Claude reads first in every session.
- `Current Context.md` is the whiteboard: what's active and where you left off.
- `Lessons Log.md` records each time you correct Claude, so the same mistake gets a fixed rule.
- `Voice Log.md` records how you change Claude's drafts, so its writing sounds more like you.
- `Connections.md` lists the apps Claude can reach, like your email or calendar.
- `Map/` holds basecamps: one note per topic that links to everything under it.
- `Calendar/` holds daily notes, one per day.
- `Downloads/` holds files you bring in, like PDFs, transcripts and screenshots. It's the one folder you fill yourself.
- `Templates/` holds the starting shape for a new basecamp and a new daily note.
- `.claude/` holds the skills (saved playbooks) and reminder scripts. Obsidian hides it.

Each folder has an About note inside that says what goes in it. You talk and Claude writes: new notes come from your conversations, so you rarely make or move a file yourself.
- `setup/` holds reminder settings for Mac and Windows, used only in the Code tab.
- `AGENTS.md` and `GEMINI.md` are pointers that send other AI apps to `CLAUDE.md`.

## Two promises

- Everything is a plain text file on your computer. You can edit or delete any of it.
- The connect skill is told never to ask for a password, key or token in the chat, and never to save one here.
