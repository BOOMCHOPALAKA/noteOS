# About Calendar

This folder holds your daily notes. A daily note is one note per day: a running log of what you worked on and what's still open. Claude writes it as you chat and when you save a session, so you don't need to make or move anything here.

## How it's filed

Claude files each day as `Calendar/<Month>/Week N/YYYY-MM-DD.md`, for example `Calendar/November/Week 2/2026-11-12.md`. It makes the month and week folders the first time it needs them.

## What's in a daily note

- **TODO:** things you own, plus open items carried over from the last note. A line that starts with `Check:` is something you're waiting on from someone else.
- **Work** and **Personal:** what happened, newest at the top. Each meeting or block of work gets its own heading.
- **Recap:** stays empty unless you ask Claude to sum up the day.

## Why it helps

When you pick up where you left off, Claude reads the latest daily note, so yesterday's decisions are still there today. You can also open any day in Obsidian and read it like a journal.
