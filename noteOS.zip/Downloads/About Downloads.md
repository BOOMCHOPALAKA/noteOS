# About Downloads

This folder holds raw inputs: files that came from somewhere else, like PDFs, meeting transcripts, exports from other apps and screenshots. It isn't your computer's Downloads folder. It's the one inside noteOS.

This is the one folder where you put files in yourself. Drop a file here and tell Claude about it, for example: `I put my lease in Downloads. Pull out the dates I need to remember.` Claude reads it and saves what matters in your notes. The original stays here as it was.

Claude doesn't write its own notes in this folder, so everything here is something you brought in.
