#!/bin/bash
# Reminder hook. When your message starts something you'll keep, it reminds Claude to check the brief.
# It never blocks.
input=$(cat)
if printf '%s' "$input" | grep -Eiq "just (do|write|make|build) it|don['’]?t ask"; then exit 0; fi
if printf '%s' "$input" | grep -Eiq "(let['’]?s|can we|can you|could you|i want to|help me) ([a-z]+ )?(build|make|create|design|plan|draft|write|set up|put together)|i want (a|an) |new (skill|page|site|video|series|script|template)"; then
  printf '%s' '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"This message may start something you will keep. Before producing it, check the brief in CLAUDE.md: is there enough context, clear instructions, and an example of good or bad? If the biggest piece is missing, ask one question about it. If the brief is complete, ignore this and do not mention it."}}'
fi
exit 0
