# Reminder hook. When your message reads like a correction, it reminds Claude to log it. It never blocks.
$raw = [Console]::In.ReadToEnd()
try { $prompt = ($raw | ConvertFrom-Json).prompt } catch { $prompt = $raw }
if ($prompt -match "(?i)(that['\u2019]?s|this is|you['\u2019]?re|it['\u2019]?s) (wrong|not right|incorrect|not what)|you (missed|forgot|skipped|should have)|why did(n['\u2019]?t)? you|did you (check|read|look)|are you sure|not what i (asked|meant|wanted)|i (already|just) (told|said|asked)") {
  Write-Output '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"This message may be a correction. Check it against the source first. If Claude got something wrong, follow the learn skill and add a row to Lessons Log.md this turn. If it was not a correction, ignore this and do not mention it."}}'
}
exit 0
