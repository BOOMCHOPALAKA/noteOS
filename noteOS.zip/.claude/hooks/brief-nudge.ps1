# Reminder hook. When your message starts something you'll keep, it reminds Claude to check the brief. It never blocks.
$raw = [Console]::In.ReadToEnd()
try { $prompt = ($raw | ConvertFrom-Json).prompt } catch { $prompt = $raw }
if ($prompt -match "(?i)just (do|write|make|build) it|don['\u2019]?t ask") { exit 0 }
if ($prompt -match "(?i)(let['\u2019]?s|can we|can you|could you|i want to|help me) ([a-z]+ )?(build|make|create|design|plan|draft|write|set up|put together)|i want (a|an) |new (skill|page|site|video|series|script|template)") {
  Write-Output '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"This message may start something you will keep. Before producing it, check the brief in CLAUDE.md: is there enough context, clear instructions, and an example of good or bad? If the biggest piece is missing, ask one question about it. If the brief is complete, ignore this and do not mention it."}}'
}
exit 0
