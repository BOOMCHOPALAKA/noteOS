#!/bin/bash
# Reminder hook. When your message reads like a correction, it reminds Claude to log it.
# It never blocks. A false match costs one ignored line.
input=$(cat)
if printf '%s' "$input" | grep -Eiq "(that['’]?s|this is|you['’]?re|it['’]?s) (wrong|not right|incorrect|not what)|you (missed|forgot|skipped|should have)|why did(n['’]?t)? you|did you (check|read|look)|are you sure|not what i (asked|meant|wanted)|i (already|just) (told|said|asked)"; then
  printf '%s' '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"This message may be a correction. Check it against the source first. If Claude got something wrong, follow the learn skill and add a row to Lessons Log.md this turn. If it was not a correction, ignore this and do not mention it."}}'
fi
exit 0
