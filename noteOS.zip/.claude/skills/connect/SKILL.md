---
name: connect
description: Use when you want Claude to reach one of your apps, like email, calendar or documents, or you ask "can you see my calendar," "connect my email" or "what can you connect to." Explains connections and sets one up with you.
---

When this skill runs, start your reply with: Using connect skill

For anything this skill looks up or explains, follow the check-answer skill: check first, then answer short.

## What this is

A connection lets Claude read from an app like Gmail, Google Calendar or Google Drive. With your permission, it can also act in that app. By default, Claude asks before it does anything on your behalf, like sending an email or sharing a file.

You stay in control. You sign in to the app yourself, in your browser, and you can disconnect it any time.

Open with that in plain words. Keep it to a few sentences.

## Steps

### 1. Ask which app

Ask one question: "Which app do you want Claude to reach first?" If they are not sure, suggest the one they named most in onboarding. Email or calendar is usually the most useful.

### 2. Start with a built-in connector

Claude has built-in connectors for common apps. They are the simplest option, so try them first.

Walk the person through it, one step at a time:

1. In the Claude app, click **Customize** in the sidebar, then **Connectors**. Older versions call this Settings > Connectors. You can also click **+** next to the message box and choose Add connectors. If the app does not show it, open claude.ai in a browser, click your initials in the lower left and look in the same place.
2. Find the app in the list and click Connect.
3. Sign in to the app when it asks, and approve the access.

The first time you use a connected app, it may send you to that app's own sign-in page. That is expected.

The desktop app passes your connectors to Claude Code. After the person connects, check by trying a small read in this session, like "list today's events." If the app does not appear in Claude Code, say so and ask them to start a new session once before you try again.

### 3. If there is no built-in connector

Say so plainly: "There is no built-in connector for that app." Then offer: "I can walk you through a manual setup, one step at a time. You run each step and tell me what you see."

If they say yes, go one step at a time. Explain what each step does and why before the person runs it. Wait for the result before the next step. Stop if something looks wrong, and say what you think is happening.

If the setup turns out to need something beyond what a person can do in a few steps, say so, and suggest they ask whoever supports their tools.

### 4. Confirm it works

Do a small read to check, like today's events or the subject lines of the last three emails. Say what you saw. If it fails, say exactly what failed and what you would try next.

### 5. Record it

When the connection works, add a row to `Connections.md`:

| App | What Claude can do | Added |

For the date, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell. In "What Claude can do," write what you confirmed in step 4, such as "Read events." Then tell the person: "The chief-of-staff skill will check this app from now on."

## Hard rules

- Never ask for a password, an API key or a token in the chat.
- Never save a password, key or token in any file in this folder.
- If a setup step needs a secret, tell the person to enter it themselves in the app's own settings. Do not read it and do not repeat it.
- Never run a setup command without the person's yes. Show the command, say what it does, and wait.
- Do not claim an app is connected until you have read something from it.
- Only list in `Connections.md` what you confirmed.
