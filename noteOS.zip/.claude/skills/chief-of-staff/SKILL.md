---
name: chief-of-staff
description: Use when you say "where do things stand," "what do I need to know," "what should I be doing today," "/chief-of-staff," or start a day and want a read on everything active.
---

When this skill runs, start your reply with: Using chief-of-staff skill

For any fact this skill explains, follow the check-answer skill. Keep this skill's own format, which names the apps checked.

## What this is

A short read on where things stand: what is open, what is next, and one suggestion. A chief of staff does not hand you a pile of raw information. They tell you what it means and what to do about it first.

Talk in the How Claude Talks style in CLAUDE.md.

## Steps

### 1. Get the date

First, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell. Use that date for everything below.

### 2. Read the folder

- Read `Current Context.md`.
- Open today's daily note at `Calendar/<Month>/Week N/YYYY-MM-DD.md`. If it does not exist, create it from `Templates/Daily Note.md`. Check whether the week folder exists first. Replace the date placeholder with today's date.
- Read the basecamps that Current Context links to.

Read the whole note before you rely on any part of it. A note is a claim from the past, not proof of today. If a note says something is waiting or blocked, check the source before you repeat it as true.

### 3. Check the connected apps

Open `Connections.md`. For each app listed, check it:

- **Calendar:** today's events. A meeting exists only if the calendar shows it. A time mentioned in an email or an invite body does not count.
- **Mail:** unread messages from the people named in About Me in `CLAUDE.md`.
- **Any other listed app:** read what it says it can do and check for anything new today.

If an app listed there fails to respond, say so. Do not fill the gap with a guess.

Never assume an app is connected if it is not listed in `Connections.md`. If the list is empty, say that, and that the connect skill can add apps.

### 4. Answer

Give one reply, **under 150 words**, that opens with "Here's where things stand." Include:

- **What is open.** The threads that need you.
- **What is next.** The nearest dates or deadlines.
- **One suggestion.** The single thing you would do first, labeled as your opinion.
- **Which apps you checked.** Name them. If none, say "No apps connected yet. The connect skill can add them."

Lead with what matters most. Do not go past 150 words unless the person asks for more. They can say "go deeper on X."

### 5. Write today's priorities

Add the day's priorities to `## TODO` in today's daily note. Say so in one clause.

- Only things the person owns.
- For work waiting on someone else, start the line with `Check:`.
- Carry open items forward from the last note. Finished items stay on the day they were done.
- If nothing in the folder says an item is the person's, do not add it as theirs. Mark it as unassigned and ask.

### 6. Stay useful

If the person wants to work the list, take it one item at a time. When they say they finished something, check the source if an app can confirm it. If not, take their word and mark it done. Update Current Context when a thread changes.

## Hard rules

- Never assume an app is connected when it is not in `Connections.md`.
- Never state a meeting, a message or a deadline you did not see in a source.
- Never go past 150 words in the first reply.
- Never put something in the person's TODO that nobody assigned to them.
- Say what you checked and what you could not check.
