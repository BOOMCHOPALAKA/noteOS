---
name: make-a-skill
description: Use when you want to turn something you do repeatedly into a new skill. Triggers on "make a skill for," "I want a skill that," "new skill," or when you describe a job you keep doing the same way.
---

When this skill runs, start your reply with: Using make-a-skill skill

## What this is

A skill is a saved playbook in `.claude/skills/`. It tells Claude how to do one job the same way every time. This skill walks you through making one. The hard part is not writing it. The hard part is knowing exactly what it should do.

## First check: have you done this twice?

Only make a skill for something you have done at least twice, or will clearly do again. If it is a one-time job, it needs a conversation, not a skill. Say that kindly and stop. If the person has done it once and wants a skill anyway, ask them to run it once more with Claude first, then come back.

## The intake

Ask these one at a time. Skip any answer you already have. Never ask them all at once.

1. **What is the problem?** "What goes wrong without this, or what takes too long?" Push for the specific friction. "Writing updates takes too long" is a start. "I spend 15 minutes collecting the same four things before every Friday update" is what you need.
2. **What triggers it?** "What would you say or do that should start it?" The answer becomes the description line.
3. **What does a good result look like?** "If it worked perfectly, what would you get back?" This is the most important question. It sets the shape of the output. Ask for an example they liked, and one they did not.
4. **What are the hard rules?** "What should it never do?" These are often the most useful part. They come from mistakes that already happened.

## Summarize back, then write

After the questions, say it back in two or three sentences: "Here is what I'm hearing: [problem], started by [trigger], giving you [result], and it must never [rule]. Does that sound right?"

Write nothing until they say yes.

## Writing the skill

Write it to `.claude/skills/<name>/SKILL.md`. Use a short lowercase name with hyphens. The file has:

1. Frontmatter, exactly two lines: `name:` (matches the folder) then `description:`. The description starts with "Use when" and says when the skill should start, not how it works.
2. One announce line right after the frontmatter: `When this skill runs, start your reply with: Using <name> skill`
3. A short explanation of what the skill is for.
4. The steps, in order, in plain words.
5. Hard rules: the things it must never do.
6. What to save afterward, if the skill produces something worth keeping.

Keep the whole file under 900 words. Cut anything that does not change what Claude does.

## Check before you call it done

- Does the description start with "Use when" and describe the trigger?
- Is the announce line there?
- Does it repeat something already in `CLAUDE.md` or another skill? If so, cut it.
- Do the hard rules cover the mistakes the person named?

Then read the skill back to them and ask what is missing. Suggest a real test: "Try saying [trigger phrase] and see if it matches what you wanted." If the new skill does not show up, tell them to start a new session.

Offer to add a row for the new skill to the Skills table in `CLAUDE.md`. Add it only if they say yes.

## Hard rules

- Never skip the intake, even for a quick skill. At least ask the problem, the good result and the hard rules.
- Never write the file before the person confirms the summary.
- Never make a skill for a one-time job.
- If the job is close to an existing skill, say so and ask whether to change that skill instead. The tune-up skill is for improving one that already exists.
- Do not edit `CLAUDE.md` without a yes.
