---
name: learn
description: Use when you correct Claude, or say "learn from this," "remember not to do that," or "that keeps happening." Logs the miss in the Lessons Log and, when the same kind of miss happens twice, proposes a fixed rule.
---

When this skill runs, start your reply with: Using learn skill

## What this is

A mistake that gets fixed in the chat disappears when the chat ends. This skill writes it down, notices when the same kind of mistake comes back, and turns that into a rule that holds. That is how this folder gets better from your own use, with no one sending you updates.

Only log what you point out. Claude does not invent a miss it was not told about.

## When it runs

- You correct Claude: "No, that is wrong," "I told you not to do that," "that is not what I asked."
- You say "learn from this" or "that keeps happening."
- The remember skill finds a correction this session that is not logged yet and you say yes to logging it.

## Steps

### 1. Fix the thing first

If the correction is about a note or a draft, fix it in the same turn. A wrong note is worse than a missing one, because later sessions read it as true.

### 2. Name the miss

Work out three things, in plain words:

- **What got through.** What Claude did or wrote that was wrong.
- **What would have caught it.** A check, a question, a rule, a habit.
- **A tag.** A short kebab-case name for the kind of mistake, like `guessed-the-date` or `skipped-the-question`. Reuse an existing tag when it fits.

If you are not sure what the person wants changed, ask one question: "What should I do differently next time?"

### 3. Check for the same tag

Open `Lessons Log.md` and look for the tag. If a row with that tag exists, set **Strike** to the next number. If not, Strike is 1.

### 4. Add the row

Add one row at the bottom of the table. For the date, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell.

| Date | Tag | Strike | What happened | Fix | Status |

- **What happened:** the miss, in the person's words where possible.
- **Fix:** what would have caught it.
- **Status:** `logged`.

Say what you did in one line: "Logged as `<tag>`, strike 1."

### 5. At strike 2 or higher, with no rule added yet, propose a rule

When the tag is at strike 2 or higher and no rule was added yet, the miss has repeated, so a note in the log is not enough. Propose one fixed rule, and say where it goes:

- `CLAUDE.md`, if it should apply everywhere.
- The skill that was involved, if it applies to one job.

Show the exact text and the place. Ask for a yes. Make the edit only after the yes. Then set Status on the new row to `rule added`, and say what changed in one line: "Added a rule to CLAUDE.md: always check today's date before writing one."

If the person says no, leave Status as `logged` and ask what they would rather change.

### 6. If a rule already exists

If the tag is at strike 3 or more and a rule was already added, the rule did not hold. Tell the person plainly. Ask whether the rule needs to be clearer, or whether the skill steps need to change. Propose one change and wait for a yes.

## Hard rules

- Never invent a miss the person did not point out.
- Never edit `CLAUDE.md` or a skill without a yes.
- One row per miss. Do not merge two different mistakes into one tag.
- Keep rules short and specific. A rule says what to do, not what to avoid in general.
- Do not scold or over-apologize. Log it, fix it and move on.
