---
name: council
description: Use when the user wants pushback or a second opinion before acting on a plan, decision, recommendation or draft, or says "run the council", "challenge this", "what am I missing", "pressure-test this", "poke holes in this" or "show the council". Independent advisors review a draft answer, then Claude gives one answer and one line on what changed. Not for simple facts or casual chat.
---

# Council

When this skill runs, start your reply with: Using council skill

Claude tends to agree with whatever idea is in front of it. The council is how this user gets real pushback: advisors who can't see each other review your draft before the user sees it.

## Size the run

- **Big:** the decision spends meaningful money, involves hiring or people's jobs, commits the user to other people, is hard to undo, or goes to leadership, a client or customers. Use all five advisors, then the reviewer.
- **Routine:** everything else. Use the contrarian and first-principles advisors.

## How the advisors run

Use the first rule that fits.

1. If advisor agents named `council-contrarian`, `council-first-principles`, `council-expansionist`, `council-executioner` and `council-outsider` are available (the council plugin installs them), hand each advisor's work to its agent.
2. Otherwise, if you can start sub-agents (Claude Code and Cowork can; ask in plain words, for example "use a separate sub-agent for each advisor"), start one per advisor. Give each one only its own section of `references/seats.md`, the person's question in their words, and your draft. No advisor sees another advisor's answer.
3. Otherwise, play each advisor yourself from `references/seats.md`, one at a time, finishing one before reading the next. Start the answer with the line `Council (single voice, not independent):` so the person knows the advisors were not separate.

## Run

1. Write your draft answer, but don't show it yet.
2. Run each advisor separately, as described in "How the advisors run." Give each one: the user's question in their own words, your draft word for word, and any facts or files the user shared. Give the outsider only the question and the draft. Never tell an advisor what you think is wrong with the draft, and never hand them an expert role or a topic briefing; each advisor picks its own expert lens.
3. If the draft states facts the decision rests on (numbers, prices, dates, rules, how a product works), also send those claims to `council-fact-checker`. If it isn't available, check the facts yourself before showing the answer (in the noteOS pack, the check-answer skill does this).
4. Big runs only: when the five answers are back, send them to `council-reviewer` labeled A to E in shuffled order, with the advisor names removed. If the reviewer isn't available, compare the five answers yourself before deciding: where they agree, where they clash, and what they all missed.
5. Decide as the chair. Change the answer where an advisor is right. Keep it where an advisor is wrong, and know why. Don't average opinions into mush; pick.
6. Show the user one answer, then one line, for example:
   - `Council: the contrarian flagged the cost, so I cut the plan to one pilot team.`
   - `Council: 2 advisors, no change.`
   - `Council: 5 advisors, split on timing; went with waiting a month because the budget resets then.`

## Show the council

When the user says "show the council" or "what did the council say," show each advisor's answer plainly, then the reviewer's, then what you changed and why.

## Don't

- Don't show the draft before the advisors return.
- Don't use the council to settle a pure fact; that's the fact checker's job.
- Don't pad the answer with the advisors' text. One line, unless the user asks.
