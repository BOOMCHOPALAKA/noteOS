---
name: check-answer
description: Use when you ask a new question that rests on facts Claude hasn't checked yet in this session or in a note with a fresh Verified date. That includes how an app or product works, the status of something, research, comparisons, and "why is this happening." Also use when the person says "show your work."
---

# Check Answer

When this skill runs, start your reply with: Using check-answer skill

The person should be able to trust the first answer. So every check happens before they see anything, and what they see is short.

## Steps

1. **Make sure you know the question.** If it could mean two things and the answers would differ, ask one question first, with the reading you'd pick. If a search can settle something, search instead of asking.

2. **Look in the folder first.** Check Current Context, the topic's basecamp in `Map/`, then its notes. If a note has a `Verified` line that is still fresh (see below), answer from it and say so: "From [[note]], checked on 11/12." Then stop.

3. **Plan.** Write down, for yourself, the facts the answer depends on, and where each one can be checked: a note, a file, a web page, the app maker's help pages, a connected app.

4. **Research.** For one or two facts, check them yourself. For more, split the work: if your tool can run sub-agents, ask for them in plain words ("use sub-agents to check these in parallel"), one for each group of sources. Claude Code does this when asked; Claude Cowork also splits big jobs on its own. Tell each one which facts to settle and where to look, and to return the source and a short quote for each fact. Don't tell them what you expect the answer to be.

5. **Check the research.** Read what came back. Every fact needs a source. Re-open anything thin, old or contradicted. App and product facts older than 30 days need a fresh source.

6. **Check it again, fresh.** Write the answer, then have one more sub-agent read only the answer and its sources and try to prove each line wrong. Fix or cut anything it breaks. If sub-agents aren't available, re-read the answer against the sources yourself, one line at a time. A line that already says "should" or "looks like" and matches its source can stay.

7. **Answer, then save.** Give the answer in the format below. Then save it (see "Save it").

## How the answer looks

- The first sentence is the answer. Then the next step, if there is one.
- Talk it through like a person. Keep it to a few sentences, or about 150 words for an explanation, unless they asked for more.
- Say where the facts came from, with links, in the sentence or in one short "Sources:" line.
- Don't describe the searching. No "I searched," no lists of what was checked.
- If something couldn't be confirmed, one line: "I couldn't confirm X. Y would settle it."
- When it fits, end with: "Want me to show where I looked?"

## Save it

Add the answer to the topic's existing note without asking (a new note, linked from its basecamp, asks first), with this line:

`Verified YYYY-MM-DD · type: <product|code|person|idea> · sources: [links]`

Check the real date first. How long it stays fresh:
- **product:** app features, prices, settings. 30 days.
- **code:** how a file or script works. Until the file's modified date is newer than the Verified date.
- **person:** what someone said or decided. Until a newer note or message says otherwise.
- **idea:** a stable concept, like what a basecamp is. No expiry.

Past its window, a `Verified` line is a lead, not proof. Check again.

## "Show your work"

When the person asks "show your work," "where did you look" or "how do you know," give them the facts, the source for each, and what was fixed or cut, plainly. Use the note's `sources:` line and anything you kept from the research.

## Don't

- Don't show an answer before step 6 is done.
- Don't ask the person something a search could answer.
- Don't treat an old or unmarked note as proof.
- Don't write a plan or promise in the person's voice that they haven't made.
