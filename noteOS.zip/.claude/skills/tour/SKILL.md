---
name: tour
description: Use when onboarding ends and the person says yes to the tour, or when you type /tour or ask how this folder works.
---

When this skill runs, start your reply with: Using tour skill

## What this is

A ten-minute walk through this folder, for someone who never read the guide. Each stop explains one thing, then they try it. Talk in the How Claude Talks style in `CLAUDE.md`.

## How to run it

- One idea per message. Wait for a reply after each.
- Explain every term the first time.
- You can't open Obsidian or see their screen. Tell them where to click, and ask what they see.
- Obsidian hides the `.md` ending (`CLAUDE.md` shows as `CLAUDE`) and the `.claude` folder.
- Write only after a clear yes, with the exact text shown first.
- About Me: add only, with a yes. Never edit or delete what is there.
- End every stop with: "Want to keep going, or stop here?"

## Stops

### 1. Notes are plain text

Say every note here is a markdown file: a plain text file whose name ends in `.md`. Any app can open it. Obsidian is a free app that shows these files as tidy notes.

Next message: "Open Obsidian and click `Start Here` in the list on the left. Tell me when it's open." If they don't have Obsidian yet, point them to the install step in the setup guide. They can also open any `.md` file in Notepad (Windows) or TextEdit (Mac) to see it's plain text. Then say a `#` at the start of a line makes a heading. That's all the formatting is.

### 2. CLAUDE.md is your rulebook

Explain: `CLAUDE.md` is the instruction file. Claude reads it every session and follows it. They can change any line, and the change applies next session. Then customize it together, one question per message:

1. If About Me says how they like answers, say it back and ask if it's still right. If not, ask: "Do you like answers short, or detailed?"
2. "What's one thing I should never do?" For example: use jargon, send anything without asking.
3. "Anything I should always keep in mind?" For example: their computer, a name people misspell.

Show the new lines, then ask: "Want me to add these to the bottom of About Me?" On a yes, add them there. If a line onboarding wrote is wrong, have them change it in Obsidian themselves.

### 3. Basecamps and links

List the basecamps in `Map/` and pick one together. Say a basecamp is one note per topic, like a trailhead sign: `## Compass` says what the topic is, and `## Trails` links the notes worth visiting. Ask them to open it.

Next message: "What's one thing under this topic that deserves its own note? A plan, a person, an idea." Offer to make a note from their answer. On a yes, make the note in the folder root, link it back to the basecamp, and add `[[Name|readable text]]` to Trails. Then have them click the new link in the basecamp.

If `Map/` has no basecamps yet (only `About Map.md`), offer to make a first basecamp from `Templates/Basecamp.md`.

### 4. Current Context and daily notes

Say `Current Context` is the whiteboard: what's active and where things left off. Claude reads it first every session. Ask them to open it.

Next message: each day gets one note in `Calendar/`, with a TODO list of what they own and what happened that day. A line starting `Check:` is something they're waiting on from someone else. The first one appears when they type `save this session`. Next time, `pick up where we left off` brings them back.

### 5. Skills

Say a skill is a saved playbook for one job, done the same way every time. List every skill in the `CLAUDE.md` Skills table by plain job, grouped like this:

- **Every day:** remember saves a session, pickup starts the next, chief-of-staff says what needs you.
- **Making things:** interview asks before writing, plan plans bigger jobs, voice drafts in your style.
- **When I get it wrong:** learn logs the correction, tune-up proposes fixes weekly.
- **Growing it:** make-a-skill turns a repeat job into a skill, connect hooks up your apps.
- **Getting started:** onboarding sets you up, tour is this walk.

Add any other skills the table lists. Show how to ask: in plain words (`save this session`) or by name (`use the remember skill`).

### 6. The logs

Say this is how it learns. When they correct Claude, the learn skill adds a row to `Lessons Log`, and a repeat of the same mistake gets a proposed rule that waits for their yes. When they change a draft, the voice skill records it in `Voice Log`, and a change seen three times becomes part of how Claude writes for them. The most useful thing they can do is say plainly when Claude gets something wrong.

### 7. Close

Recap what they changed today in one line. Then end with, word for word: "This is your foundation. Change anything. The more we work here, the more it knows."

## Stopping

If they stop, say: "No problem. Ask for the tour any time and tell me we stopped at [stop name]. I'll start there." Don't push.
