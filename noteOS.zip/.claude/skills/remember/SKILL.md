---
name: remember
description: Use when you say /remember, "save this session," "log this chat," or ask to save what you covered in this session. Claude also offers it after a big block of work, at the end of the day, or after a major decision.
---

When this skill runs, start your reply with: Using remember skill

## What this is

A save point. When it runs, Claude reviews the session, writes what matters to the right notes, and updates `Current Context.md` so the next session can pick up cold. You should not have to say what to save or where.

Offer it only at real breakpoints: wrapping up, a big decision, a long block of work that is closing out. Name what you would save: "Want me to save this session? We covered X, Y and Z." For a single fact in the middle of a conversation, write it where it belongs.

Talk in the How Claude Talks style in CLAUDE.md.

## Steps

### 0. Get the date

First, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell. Use that date and time on every entry. Do not trust the date the session started with.

### 1. Check for corrections

Before saving, look back through the session for times the person corrected you. If any are not in `Lessons Log.md` yet, say so and offer the learn skill for each one. Do not log them yourself unless they say yes.

### 2. Gather what happened

Scan the conversation for:

- Decisions made
- New facts about people, projects or plans
- Findings from research or investigation
- Status changes on existing work
- Action items
- Problems found or solved
- Anything a future session would need

### 3. Decide where each item goes

| What | Where |
|---|---|
| What happened today, meeting notes, quick updates | Today's daily note, under `## Work` or `## Personal`, newest at the top |
| Action items | Today's daily note `## TODO`. Yours only. Use `Check:` for things you wait on from someone else |
| What is active, blocked or next | `Current Context.md` |
| New facts about a topic | The existing note, or its basecamp in `Map/` |
| A topic with enough substance for its own note | Ask first, then create it |

Every session gets at least a daily note entry and a Current Context refresh. The daily note lives at `Calendar/<Month>/Week N/YYYY-MM-DD.md`. Check whether the week folder exists before you make one. If today's note does not exist, make it from `Templates/Daily Note.md`.

### 4. Write the updates

- **Read the whole file first.** Never write blind.
- **Change the section that needs it.** Do not rewrite the file.
- **Link new notes** to a basecamp or a related note.
- **Stamp every entry with the date.**

**Current Context is the bridge between sessions.** Write it for a reader who has never seen this conversation. For each active thread, say:

1. Where things stand right now, not the history.
2. Where you stopped.
3. The next step.
4. Which notes to read for the full picture, as links.

Remove finished items. Keep other sessions' entries.

### 5. Sweep

Before you report, check for anything worth keeping that you did not save. Be specific: "We talked about X and I did not write it down. Want it in [note name]?" Never ask a vague "anything else?"

If a topic now has three or more notes and no basecamp, suggest one. If a decision or finding will be needed on its own later, suggest a standalone note. If neither applies, say nothing.

### 6. Report

Give a short summary: which files changed and what went where. Then a few bullets that recap the session, one per topic, one or two sentences each. End with where the next session will start. Then close with: "Got it, saved. Today's note and Current Context are up to date."

## Hard rules

- Every claim you write comes from the conversation. If you are inferring, say "my read" or leave it out.
- If the person hedged ("I think," "should be"), keep the hedge in the note.
- Do not write "launched," "decided" or "approved" unless the conversation shows it.
- Do not write to `## Recap` unless asked.
- Ask before creating a new standalone note. Daily note entries and section updates do not need a yes.
- If nothing new happened since the last save, write a short entry that says so. Do not save the same thing twice.
