---
name: voice
description: Use when you ask Claude to draft, write or reply as you: emails, messages, posts, comments, updates. Also when you paste back a version you changed, so Claude can learn from it.
---

When this skill runs, start your reply with: Using voice skill

## What this is

Claude drafts in your voice, then learns from every change you make. The goal is a draft you can send without changing a word. Your own words are the raw material. Claude assembles from them. It does not invent the substance.

## Before you draft

1. **Read your voice.** Read the `## Voice` section of `CLAUDE.md`, the `## Samples` and `## Patterns` in `Voice Log.md`, and the last five rows of Entries.
2. **Check you have the basics.** Who is this going to? What do you want to happen after they read it? What is the thread or history? If something is missing and changes the message, ask. A bad draft costs more time than one question.
3. **Check the substance is in your words.** If the person has not told you what they want to say, do not make it up. Use the interview skill first: one question at a time, then assemble from the answers. Skip the interview when the raw material already exists in their words, like a thread you have read or notes they wrote, or when they say "write it now."
4. **Read the thread.** If you are replying to something, read it first. Do not repeat what the person already sent, re-ask what the other side already answered, or explain what they already know.
5. **Do you have enough of their writing?** If `## Samples` and `## Patterns` are both empty and you have seen no sample, say so and ask for one or two real messages.

## Drafting

- Use their phrasing wherever it works. Do not tighten it into something more polished.
- Keep the order they talked it through in.
- Add no section they did not speak to.
- Fill in only the glue: transitions and grammar.
- After the draft, list every place you filled a gap with your own words, in short bullets. If there are none, say so.

## Voice basics

These apply until the log teaches something better.

- Plain words, short sentences, no jargon the reader does not share.
- Match the other person's formality. Closer peers get shorter and looser messages.
- Say what you think and how sure you are. "Looks like" and "I think" are fine. Do not declare things you have not checked.
- Open on the substance. Skip praise that could be pasted into any message.
- No em dashes or en dashes.
- No phrases like "I hope this finds you well," "circle back" or "touch base."
- No emoji unless the person uses them with this reader.

## The learning loop

**Whenever you see what the person actually sent** (they paste their version, or tell you what they changed), compare it with your draft.

1. Add one row to Entries in `Voice Log.md`: today's date, what Claude wrote, what they changed it to, and the pattern in a few words. For the date, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell.
2. Log structure as well as wording: the order of the paragraphs in your draft and in theirs, and anything cut or moved.
3. Count the pattern. **When the same pattern has shown up 3 times**, add it as a line under `## Patterns` and tell the person: "I noticed you always do X, so I added it to your voice patterns." Write `(added)` after the text in the Pattern cell of those Entries rows, so the same pattern is never promoted twice.
4. Mention the log in one clause at most. Do not make a production of it.

If they wrote something from scratch, log the notable choices the same way. The sent version is the voice. Your draft is the error to learn from.

When you rewrite a draft after feedback, check that nothing fell out. Name anything you dropped before handing it back.

## Hard rules

- Never send anything. Show the draft and stop.
- Never draft from invented substance.
- Never add a pattern to `## Patterns` before it has shown up 3 times.
- Never present a guess about what someone else thinks or feels as fact.
