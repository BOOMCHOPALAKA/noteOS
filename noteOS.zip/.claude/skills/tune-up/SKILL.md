---
name: tune-up
description: Use when you want to improve a skill based on how it has actually performed, or on a weekly check. Triggers on "tune up," "improve the [name] skill," or "this skill keeps getting [thing] wrong."
---

When this skill runs, start your reply with: Using tune-up skill

For anything this skill looks up or explains, follow the check-answer skill: check first, then answer short.

## What this is

A weekly look back. Claude reads `Lessons Log.md` and `Voice Log.md`, finds where a skill is close but not right, and proposes small edits backed by evidence. You approve each edit before anything changes. A habit works best once a week. Offer it if a week has passed since the last run.

## Steps

### 1. Pick the target

If the person named a skill, use it. If not, read the logs and pick the skill with the most rows. Say which one and why.

### 2. Read the skill

Read its whole `SKILL.md` in `.claude/skills/<name>/`. You are improving what is there, not starting over. If the skill barely exists or is badly broken, say so and suggest the make-a-skill skill instead.

### 3. Gather evidence

Use what already exists. Do not add new logging.

- `Lessons Log.md`: rows whose tag, What happened or Fix name this skill or its output.
- `Voice Log.md`: if the target is the voice skill, the Entries and any patterns not yet promoted.
- The notes the skill produced: read a few recent ones.
- Ask the person what they have noticed, if the logs are thin.

If the evidence is thin, say so plainly: "I found two rows. That is a small base." Then ask for what they have seen. Never invent history to justify a change. If there is nothing to learn from yet, say that and stop.

### 4. Find the patterns

Look for four things, and label each as **sourced** (found in these rows, with which ones) or **my read** (my inference, for you to judge):

1. What the skill gets almost right, again and again.
2. What a good result needs that the skill never says.
3. What else the skill should do.
4. What the skill makes you check that it could check itself.

### 5. Propose edits, one at a time

For each edit, show:

- The finding and the rows behind it.
- The exact before and after text.
- Where it goes: the skill, or `CLAUDE.md` if it applies everywhere.

Then ask for a yes. Wait for the answer before showing the next edit. Small additions can go together if the person says so. A change that reshapes the skill gets its own yes.

### 6. Write back

Make only the approved edits, in the skill's existing style. Keep the skill under 900 words. Add a line at the bottom of the file:

`<!-- tuned YYYY-MM-DD: what changed, because of which rows -->`

If a finding is a one-time fix and not a repeating pattern, offer to log it in `Lessons Log.md` instead of editing the skill.

## Hard rules

- Never edit anything without a yes.
- No edit without evidence. Every change names the rows behind it.
- Never invent runs or rows.
- Do not rewrite the skill. Make targeted edits that match its structure and voice.
- Keep what works. Add and refine. Remove something only with a stated reason.
- If the fix belongs in a different skill or in `CLAUDE.md`, say so. Do not stuff it into the target.
