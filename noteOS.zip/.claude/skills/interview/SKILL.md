---
name: interview
description: Use when you are about to make something that will be kept (a plan, a document, a message, a page, a skill) and it could take more than one shape. Also when you say "interview me" or "ask me questions first."
---

When this skill runs, start your reply with: Using interview skill

## What this is

Most people can talk for an hour about something they would struggle to write in five minutes. This skill gets the talking out of you one question at a time, then builds the result from your own words. The questions improve the input. The rule about what Claude does with your answers is what keeps the result sounding like you and not like a template.

## When to use it

Use it when Claude would otherwise have to invent the substance: an email, a plan, a post, a proposal, a skill.

Skip it when:

- The material already exists in your words or a source Claude has read, like a thread, a note or a transcript. If one gap shows up, ask about that gap only.
- You gave complete instructions, or said "write it now."
- It is a factual question with one right answer.

If you are not sure, ask once: "Want me to ask a few questions first, or take a swing?"

## Before the first question

Search first. Look in this folder for notes on the topic and for past examples. Ask the person only for what the folder cannot tell you. If you find a likely example, lead with it: "I found this. Is this what good looks like?"

Then say two things in one short message:

- **How long it will take.** Usually three to five questions, a few minutes.
- **What comes out.** Name it: "At the end you will have a draft email in your words."

## Running the interview

- **One question per message.** Never a list. Five questions at once get five shallow answers.
- **Build each question on the last answer.** If an answer opens a thread, follow it. If someone gestures at an idea without saying it, ask them to say it plainly.
- **Lead with a recommendation when you have one.** People answer a proposal faster than an open question. "I'd open with the deadline. Does that fit, or is something else the lead?"
- **Ask about substance, not format.** "What is the one thing they should take away?" Not "How formal should it be?"
- **Do not repeat their answer back between questions.** Ask the next question.
- **Stop at three to five questions,** or sooner when you have enough. If the person starts talking at length, that is the material. Let them go.

Good questions:

- What is the one thing they need to take away?
- What part are you worried about landing wrong?
- Why does this matter to them?
- What would you say if you were telling me out loud?
- What are you leaving out on purpose?

## Check the brief

Before you build, check three things. If one is missing and it would change the result, ask for the biggest gap first.

1. **Context.** What is this for, who will read it, what has been tried?
2. **Instructions.** What does done look like? What must not happen?
3. **Examples.** Ask for them by name: "Do you have an example of this done well? Or one you did not like?" Ask for the bad one too. People rarely offer examples unprompted.

"No" is a fine answer. Say what you will assume and move on.

## Assemble from their words

When the interview is done, these rules are strict:

- **Keep their phrasing.** If they said it in a way that works, use it. Do not clean it up.
- **Keep their order.** The order they talked in is probably the right order.
- **Add no section they did not speak to.** If they did not mention it, it is not in the draft.
- **Fill only the glue.** Transitions and grammar, the minimum that makes their words read as one piece.
- **Then list every gap you filled.** After the draft, add short bullets: where you wrote something the person did not say. If the list is empty, say so.

## Hard rules

- Never ask a list of questions at once.
- Never repeat their answers back between questions.
- Never invent substance and present it as theirs.
- Never round the piece out with extra sections for completeness.
- If you filled a gap, say so every time.
