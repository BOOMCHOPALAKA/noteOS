---
name: pickup
description: Use when you say /pickup, "pick up where we left off," "what were we working on," or want to resume earlier work. The partner to remember: remember saves, pickup loads.
---

When this skill runs, start your reply with: Using pickup skill

## What this is

A fast way back into your work. Claude reads what the last session saved and tells you where things stand, so you do not have to explain it again.

Talk in the How Claude Talks style in CLAUDE.md.

## Steps

### 0. Get the date

First, check today's date with `date '+%Y-%m-%d %H:%M'` on Mac or Linux, or `Get-Date -Format "yyyy-MM-dd HH:mm"` on Windows PowerShell. The gap between "last time" and now depends on it. If file dates and the session's starting date disagree, trust the files and the command.

### 1. Read Current Context

Open `Current Context.md`. Note which threads have the newest dates and which notes they link to.

### 2. Read the latest daily note

Find the newest daily note under `Calendar/` (skip `About Calendar.md`). Read its TODO list and the entries at the top of `## Work` and `## Personal`. They often hold details that Current Context left out: a decision still open, something that felt off.

### 3. Read what they point to

Follow the links that matter, and only those. Do not read the whole folder.

### 4. Orient

Open with "Hey, welcome back. Here's where we left off:" Then give a short briefing, five lines or fewer:

- **Where you left off.** One or two sentences.
- **Open threads.** The ones with a clear next step, most actionable first.
- **Waiting on others.** Anything you saw marked `Check:`, and what you know about it.
- **Needs attention.** Anything time-sensitive or old.

### 5. Ask

End with: "Where do you want to pick up?" and two to four numbered options. Each gets a short label and one line on where it stands. The person can answer with a number. Put the most urgent first.

## Hard rules

- Read before you brief. Never answer from memory.
- Do not guess at state. If a note says "waiting on Sam," report that as what the note says, with its date, not as a fact about today.
- Do not summarize the whole folder. Only what the last session and the active threads need.
- Keep it to five lines. If the briefing runs past a screen, cut it.
- If Current Context is empty and there are no recent notes, say so plainly and ask what they are working on. Do not invent context.
