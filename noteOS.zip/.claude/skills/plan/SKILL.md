---
name: plan
description: Use when you say "/plan," "let's plan," "help me plan," "I want to build," or describe something that will be kept and could take more than one shape: a page, a document, a skill, a project with several parts.
---

When this skill runs, start your reply with: Using plan skill

## The idea in two sentences

Opus is the architect: the stronger model that thinks through the problem and writes the plan. Sonnet is the cheaper crew that does the work once you approve the plan. A good plan from the architect lets the crew do careful work without the cost of having the architect build every step.

If the request is a quick command, a question or a single message, it does not need a plan. It needs a conversation.

## Steps

### 1. Interview

Use the interview skill. Ask what the person wants, one question at a time, and check the brief: context, instructions, examples. Do not write a plan from a guess.

For anything that is a workflow, start with: "Walk me through the last time you actually did this." Design for what they really do, not for what sounds tidy.

### 2. Write the plan

Write the plan as a note named `<Thing> - Plan.md` in the folder root. Open it with a `## Compass` section: a short summary and links to related notes or the basecamp. Link it from the right basecamp in `Map/`.

The plan lists the steps in order. Every step has:

- **What gets made or changed.** Name the exact file or note.
- **The check.** How you and the person will know the step worked. Make it something you can look at or run, not "looks good."

Gather the facts before you write, so no step says "TBD" or "similar to step 2." If a step needs a decision the person has not made, ask now.

In Plan mode (see below), Claude cannot write files yet. In that case, show the plan in the chat, and save it as the note as the first thing you do after the person approves.

### 3. Get a yes

Stop and ask: "Does this plan hold?" Build nothing until the person says yes. If they add an idea, name what it changes in the plan before you agree.

### 4. Build

Work through the steps in order. After each one, run its check and say what you saw. If a check fails, stop and say so. Do not move on and hope.

When the last step is done, give a short final message that stands alone: what was built, which checks passed, where the files are, and the one thing the person needs to decide or do next. If they used Accept edits, remind them to switch back to Manual. Add a `Built:` line with the date to the plan note.

## Splitting the work between Opus and Sonnet

Claude Code can use one model to plan and a cheaper one to build. Tell the person how, based on where they are.

**In the Terminal:** type `/model opusplan`. Claude plans with Opus, then switches to Sonnet when you approve the plan and start building.

**In the Claude desktop app, Claude Code:**

1. Before you start, pick Opus in the model menu and Plan mode in the mode menu. Claude will write the plan and will not change any files.
2. Read the plan.
3. Switch the model to Sonnet. Do this before approving, in case approving starts the build.
4. Approve the plan. If the app asks how to proceed, pick the option that lets you approve edits yourself, then choose Accept edits in the mode menu. Now Claude builds.

**Warning:** Accept edits lets Claude edit, copy, move, rename and delete files in the folder without asking you first. Use it only after you have read the plan, and check the plan's list of files before you switch.

If you cannot find the menus, tell the person to look near the message box, and offer to stay on one model. A plan on one model still works. The split only saves cost.

## Hard rules

- Never build before the person says yes to the plan.
- Never write a step without a check.
- Never write a step that says "TBD," "add error handling" or "similar to the last step."
- Do not switch to Accept edits on your own. Tell the person to do it and why.
- Do not use this for a quick command, a question or a single message.
