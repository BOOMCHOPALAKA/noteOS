# Setup Guide for Windows

## 1. What you're setting up

You're setting up a shared notebook for you and Claude: a folder of notes on your PC. You read them in an app called Obsidian. Claude works in the same folder through Cowork, part of the Claude desktop app, and learns how you like to work. Day 1 takes about 30 to 45 minutes (a rough guess). Each day after that, you try one new habit in a few minutes. This guide is written for Claude. Other AI apps that can work in a folder on your computer, like ChatGPT's desktop app, should work too, since the notes and instructions are plain text files. Start the same way: Read CLAUDE.md in this folder and follow it. A guide for other apps is in the works.

**What you need:** a Windows PC, an internet connection, and a paid Claude plan (Pro, Max, Ultra, Team or Enterprise). Cowork needs a paid plan.

**How to read this guide:** each step ends with a line that starts "You should see:". If your screen matches, move on. If not, the step says what to do.

## 2. Words you'll see

- **Obsidian:** a free app for reading and writing notes in a folder.
- **Markdown file:** a plain text file whose name ends in `.md`. Obsidian shows it as a tidy note.
- **Cowork:** the part of the Claude desktop app where Claude works with the files in a folder you pick. Its sessions run in the cloud, on Anthropic's servers. (Anthropic makes Claude.)
- **CLAUDE.md:** the instruction file in your folder. It's the rulebook. In Cowork, you ask Claude to read it at the start of a session.
- **Skill:** a saved playbook in your folder. Each one tells Claude how to do one job the same way every time, like saving a session or drafting an email.
- **Basecamp:** one note per topic (a project, a client, a hobby) that links to every note under it.
- **Daily note:** one note per day, holding your to-do list and what happened that day.
- **Current Context:** the whiteboard note that says what's active and where you left off.
- **Session:** one conversation with Claude.
- **Connection (MCP):** a link between Claude and one of your apps, like email or calendar. In the Claude app they're called connectors.
- **Claude Code** (labeled Code in the app): another part of the Claude app that works with the same folder. It's optional. Section 10 covers what it adds.

## 3. Day 1: install and meet it

### Step 1. Install Obsidian

1. Open your web browser and go to obsidian.md/download.
2. Under Windows, click **Universal** to download the installer.
3. Open the downloaded file and follow the instructions.
4. Open Obsidian from the Start menu.

You should see: an Obsidian window with a few choices, one of them **Open folder as vault**. Leave it open for now.

### Step 2. Install the Claude desktop app and find Cowork

1. In your browser, go to claude.com/download and download the Windows version. Most PCs need the standard version, called x64. If your PC has an ARM processor, pick the ARM64 version. To check, open **Settings > System > About** and look at **System type**.
2. Open the downloaded file and follow the instructions. If Windows asks whether to let the installer make changes, click Yes.
3. Open Claude from the Start menu and sign in with your Claude account.
4. Find **Cowork**. Depending on your app version, it's a tab at the top of the sidebar on the left or an option near the box you type in. If the tabs show only icons, hover over each one to see its name. Click Cowork.

If you're asked to upgrade, subscribe first, then come back. If you don't see Cowork, go to "Cowork doesn't show up" in section 11.

You should see: Cowork open, with a box to type in.

### Step 3. Unzip noteOS.zip, move it to Documents, and open it in Obsidian

Move the folder to Documents before you open it anywhere. This folder is Claude's home, and Downloads tends to get cleaned out.

1. Open File Explorer and find `noteOS.zip` in your Downloads folder.
2. Right-click `noteOS.zip` and choose **Extract All**. Keep the location it suggests. Don't click **Browse** to pick another place, because the files then land loose in that place instead of in a folder. Click **Extract**.
3. A folder named `noteOS` opens. Check that you have the right one. It holds `CLAUDE.md` and `README.md`. Move that folder into your Documents folder. You can rename it, for example to `Notes`.
4. In Obsidian, click **Open** next to **Open folder as vault**. ("Vault" is Obsidian's word for a folder of notes.)
5. Pick the folder in Documents, and click **Open**.

You should see: Obsidian with a list of files on the left, including `CLAUDE`, `Current Context`, `Start Here` and the folders `Calendar`, `Map` and `Templates`. Obsidian hides the `.md` at the end of each name and hides the `.claude` folder. That's normal. File Explorer still shows `.claude`.

### Step 4. Open the folder in Cowork and send the first message

1. In Cowork, choose your notes folder in Documents. Look for a folder control near the box. If you don't see one, go on to the next step. Cowork asks you to pick a folder the first time it needs files.
2. Type this exactly, and press Enter:

   `Read CLAUDE.md in this folder and follow it.`

In my test, Cowork didn't read CLAUDE.md on its own: `hi` got a generic reply. This sentence points Claude at your instruction file.

**Prompts come next.** Two prompts from Claude are expected. The wording below comes from a test on a Mac, so yours may look a little different. The prompt shows your folder's name, so if you renamed your noteOS folder, you see that name instead of "noteOS."

1. **"Allow Claude to change files in "noteOS"?"** with the buttons Cancel, Always allow and Allow. Click **Always allow**, since Claude writes notes here. Do this for your notes folder only. Never for a folder of original footage or anything you can't replace.
2. **"Allow Claude to access this folder?"** It says the session runs in the cloud and the files Claude uses are processed on Anthropic's servers. Check **Don't ask again for this folder on this device**, then click **Allow**. Because of this, keep private files and original footage out of this folder.

We don't know yet whether Windows adds a prompt of its own. If one appears and asks about Claude and this folder, **Allow** is the right answer.

Claude now runs the **onboarding** skill. It asks about six questions, one at a time, about you, your work and how you like answers. Short answers are fine. As you answer, Claude writes notes in your folder. If it asks to run a short command, like one that reads today's date, allow it. If you see red error text, type: `that command failed, try another way`.

Near the end, Claude asks: "One setup thing: can I save a note in this folder's instructions so I read CLAUDE.md first every time you open it?" Say yes. This part is new and hasn't been tested yet. If it doesn't stick, nothing breaks. You start each session with the same first message. If Claude mentions reminders as a Claude Code extra, you don't need them today.

Last, Claude offers a short tour of how all this works. Say yes. It takes about ten minutes, shows you around your folder in Obsidian, and helps you change your instruction file. You can stop any time.

You should see: a card labeled "Folder" with your folder's name above your message, and a "Used in this session" panel listing your computer and the folder. (That's how it looked on a Mac.) Claude's first reply starts with "Using onboarding skill" and a welcome. When the questions are done, Claude should sum up what it made. In Obsidian, `Map` should hold a basecamp for each area you named, and `CLAUDE` should have your About Me filled in. If onboarding doesn't start, go to "Onboarding didn't start" in section 11.

### Step 5. Start a fresh session and open Start Here

1. Start a new session in Cowork. Look for **+ New** or a new task button in the sidebar. Choose the same notes folder.
2. Type: `what do you know about me?`
3. If the reply doesn't use what you told Claude, type `Read CLAUDE.md in this folder and follow it.` and ask again. That means the folder note from step 4 didn't stick. Start each new session with that sentence.
4. In Obsidian, open `Start Here`. It's a one-page map of your folder.

You should see: a reply that uses what you told Claude during onboarding, and Start Here with a welcome and a list of what's in the folder. You're set up. Use it for real work for the rest of the day.

## 4. Day 2: remember and pickup

**A habit for every session:** in Cowork, choose your notes folder. If Claude doesn't seem to know you or your folder, send `Read CLAUDE.md in this folder and follow it.` first.

### Step 1. Save the session

At the end of a working session, type `save this session`. The **remember** skill reviews the conversation, writes what happened into today's daily note and updates Current Context.

You should see: a reply that starts with "Using remember skill," a short list of what went where, and "Got it, saved." In Obsidian, a new note appears under `Calendar`, in a folder for this month and week, named with today's date.

### Step 2. Pick up the next morning

The next morning, start a new session in Cowork, choose your folder, and type `pick up where we left off`.

You should see: a reply that starts with "Using pickup skill," then "Hey, welcome back," a short briefing of where you left off, and two to four numbered options. Reply with a number to start.

## 5. Day 3: interview and voice

### Step 1. Let Claude interview you

Ask for something you'd write anyway: `help me write a post about our spring plans`, or a short script for a video. The **interview** skill asks questions one at a time and builds the draft from your answers, so it sounds like you.

You should see: one question at a time. After three to five answers, a draft, with a list of any gaps Claude filled with its own words.

### Step 2. Change one line and watch the Voice Log

Rewrite one line of the draft the way you'd really say it. Paste your version back and say `here's what I changed`. The **voice** skill compares the two.

You should see: a new row in `Voice Log` (open it in Obsidian) showing what Claude wrote, your change and the pattern. When a pattern shows up three times, Claude adds it to your voice patterns.

## 6. Day 4: plan

Today you plan something with a few parts, like a trip, a small project or a series of posts. The **plan** skill has Claude think the whole thing through and write a plan before it makes anything.

### Step 1. Ask for the plan

Type `let's plan` and describe the thing in a sentence. Claude interviews you first, then shows the plan in the chat. Every step in the plan names what gets made and how you'll check it worked.

You should see: a reply that starts with "Using plan skill," some questions one at a time, then a numbered plan and the question "Does this plan hold?" Read it. Say yes, or say what to change.

### Step 2. Let Claude build it

Say yes when the plan looks right. Claude saves the plan as a note (if it hasn't already) and works through each step. If Claude talks about switching models or modes, that's a Claude Code extra (section 10). In Cowork, you can stay as you are.

For a footage job, copy one folder of clips into `Downloads/` inside your notes folder, and only clips you're fine sending to Anthropic's servers. Keep the originals, and a backup, where they are.

You should see: after each step, Claude says what it checked. At the end, a short message lists what it built, which checks passed and where the files are.

## 7. Day 5: connect and chief-of-staff

### Step 1. Connect one app

Type `connect my calendar` (or email). The **connect** skill walks you through it one step at a time. You sign in to the app yourself, in your browser. Never type a password, key or token into the chat.

Claude starts with the connectors built into Claude. You manage them under **Customize > Connectors** in the sidebar (older versions: **Settings > Connectors**).

You should see: Claude tries a small read, like today's events, and tells you what it found. `Connections` gets a new row for the app. If the connection doesn't appear, start a new session and ask Claude to try again.

### Step 2. Ask where things stand

Start your day by typing `where do things stand`. The **chief-of-staff** skill reads Current Context, today's note and each app in Connections, then gives you a short read.

You should see: a reply that starts with "Using chief-of-staff skill," then "Here's where things stand," under 150 words: what's open, what's next, one suggestion and which apps it checked.

## 8. Week 2: learn, tune-up, make-a-skill

### Step 1. Correct Claude once

The next time Claude gets something wrong, say so plainly, like `that's wrong, the meeting is Thursday`. The **learn** skill fixes the mistake and writes it down. If Claude fixes it but doesn't log it, type `log that with the learn skill`.

You should see: Claude fixes the thing and says something like "Logged as `wrong-day`, strike 1." `Lessons Log` gets a new row. If the same kind of mistake happens again, Claude proposes a fixed rule and waits for your yes.

### Step 2. Run a tune-up

Once a week, type `tune up`. The **tune-up** skill reads your Lessons Log and Voice Log, picks one skill and proposes small edits, one at a time.

You should see: a reply that starts with "Using tune-up skill," then one edit with the before and after text. Nothing changes until you say yes. If the logs are thin, Claude says so. That's expected in week 2.

### Step 3. Make your first skill

Think of something you've done twice the same way, like a packing list. Type `make a skill for` and name it. The **make-a-skill** skill asks a few questions, sums up and waits for your yes before it writes. When it offers to add the skill to the list in CLAUDE.md, say yes. That list is how Claude finds it later.

You should see: a new `SKILL.md` in `.claude/skills`. Obsidian hides `.claude`, so ask Claude `show me the new skill`. To try it, ask for it by name, like `use the packing-list skill`.

## 9. How the pieces fit

- **CLAUDE.md is the rulebook.** It holds your About Me and the habits Claude follows.
- **Skills are playbooks.** CLAUDE.md lists each one with its file. Describe the job or ask for a skill by name, and Claude opens its file. Any AI that can read this folder can do the same.
- **Basecamps are hubs.** Claude reads the basecamp in `Map` first, so it finds things fast.
- **Logs are how it learns.** Lessons Log holds your corrections and Voice Log your edits. The tune-up skill reads both. Nothing changes without your yes.
- **You can change any file.** These are plain text files on your PC. Claude reads the new version next session.

## 10. Want more? Claude Code

Cowork covers Days 1 to 5. Claude Code is an optional extra in the same app, with the same folder and notes. It adds three things:

- **Skills start on their own.** Claude reads CLAUDE.md without being asked, so `hi` works as a first message. Describe a job and its skill starts. You can also type `/` and a skill's name, like `/pickup`.
- **Two reminders.** Small scripts, called hooks, nudge Claude to log corrections and check the brief.
- **The Opus and Sonnet split for Day 4.** Opus, the stronger model, writes the plan. Sonnet, which costs less, does the work.

### Step 1. Open your folder in Claude Code

1. Click **Code** in the app. On a Mac it's the `</>` icon at the top left, next to the chat icon. I haven't seen it on Windows, so look for that icon or the word Code. That opens Claude Code.
2. In the row of small controls under the box, click the first one. This is the environment selector. Choose the top entry in the **Local** group, which means "on this PC." (Skip any WSL entry. It's for a Linux setup you don't need.)
3. Click the folder control next to it, choose **Open folder…**, and pick your notes folder.
4. In the mode menu in the same row, choose **Manual**. In Manual mode, Claude asks before it changes a file, and you approve each change.
5. Type `hi` and press Enter.

If the app asks whether you trust this folder, say yes. If the controls sit above the box, choose the folder there, or update the app. If a command fails with red error text, type: `that command failed, use the Windows PowerShell version`. (PowerShell is the command tool that comes with Windows. Git for Windows, a free tool some Claude Code setups use, is optional. Ask Claude about it later if you like.)

You should see: a reply that knows who you are. If About Me is still empty, onboarding starts instead, and it sets up the reminders at the end.

### Step 2. Turn on the reminders

1. Type: `copy setup/windows/settings.json to .claude/settings.json`
2. The app asks you to approve the change. Approve it.
3. Click **+ New** (or press Ctrl+N) and choose the same folder. The reminders load when a session starts.

You should see: Claude says it copied the file. The reminders work quietly from the next session on. If they don't seem to work, ask Claude `does .claude/settings.json exist in this folder?` and copy it again if it doesn't. The Windows reminders are small PowerShell scripts, new and not yet tested on a real Windows PC. If you see an error about a script, Claude still works. Tell the person who shared noteOS with you.

### Step 3. Split planning between Opus and Sonnet

1. Click **+ New** and choose your folder.
2. Open the model picker in the row under the box and choose **Opus**. (Ctrl+Shift+I also opens it.)
3. Open the mode menu and choose **Plan**. (Ctrl+Shift+M also opens it.) In Plan mode, Claude proposes a plan without changing any files.
4. Type `let's plan` and describe the thing. Read the plan.
5. Before you approve, switch the model to **Sonnet**, in case approving starts the build.
6. Approve the plan. If the app asks how to proceed, pick the option that lets you approve edits yourself, then choose **Accept edits** in the mode menu.

**A warning about Accept edits.** In this mode, Claude edits, copies, moves, renames and deletes files in your folder without asking first. It still asks before other commands. Check the plan's list of files before you switch, or choose **Manual** to approve each change. When the build is done, switch back to **Manual**. If you can't find a menu, stay on one model. The split only saves cost.

You should see: Opus and Plan in the row while you plan, then Sonnet and Accept edits while Claude builds. If a model isn't in the list, ask Claude: "Which models can I pick, and which is best for this?"

## 11. If something looks wrong

### Cowork doesn't show up

Update the app with **Help > Check for Updates…**, then reopen it. Cowork needs a paid plan. On a Team or Enterprise plan, your admin may need to turn it on.

You should see: Cowork in the sidebar or near the box. If it still isn't there, Claude Code (section 10) runs onboarding too.

### Onboarding didn't start

Check that you typed the first message exactly: `Read CLAUDE.md in this folder and follow it.` Then check the folder. A card labeled "Folder" with your folder's name should sit above your message. If it's missing or names another folder, start a new session, pick your notes folder with the folder control near the box, and send the first message again.

Then check About Me. Onboarding runs when About Me in CLAUDE.md is empty. If it has text from an earlier try, delete that text in Obsidian, keep the heading, and start a new session. You can also type `use the onboarding skill`.

You should see: a reply that starts with "Using onboarding skill."

### A skill doesn't run

Send `Read CLAUDE.md in this folder and follow it.` first, then ask for the skill by name and file, for example: `use the pickup skill in .claude/skills/pickup/SKILL.md`. Make sure the session is using your notes folder, because the skills live there.

You should see: the reply starts with "Using pickup skill" (or the skill's name). If not, ask Claude: "Which folder is this session using, and can you see the skills in .claude/skills?"

### You clicked the wrong button on a prompt

If you clicked Cancel on a Claude prompt, start a new session with your notes folder and send the first message again. The prompt should come back.

You should see: Claude can read and write notes in your folder again.
