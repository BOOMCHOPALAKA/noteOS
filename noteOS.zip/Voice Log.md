## Compass

When you edit a draft Claude wrote, the voice skill records the difference here. A pattern moves into the voice skill after Claude has seen it 3 times.

## Samples

Writing you pasted that sounds like you. Claude reads these before it drafts.

## Patterns

## Entries

| Date | What Claude wrote | What you changed it to | Pattern |
|---|---|---|---|
