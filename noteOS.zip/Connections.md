## Compass

This is the list of apps Claude can reach. The chief-of-staff skill checks every app listed here, and the connect skill adds a row each time you set one up.

| App | What Claude can do | Added |
|---|---|---|
