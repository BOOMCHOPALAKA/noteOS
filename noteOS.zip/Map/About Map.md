# About Map

This folder holds your basecamps. A basecamp is one note per topic, like a project, a client, a hobby or a person. It links to every note about that topic. Think of the trailhead sign at a park: it doesn't hold the whole park, it shows you where each path goes.

Claude makes your first basecamps during onboarding, one for each area you mention. After that, it adds each new note to the right basecamp's links, and it suggests a new basecamp when a topic has three or more notes.

## What's in a basecamp

- **Compass** at the top: what the topic is and why it matters, plus links to related notes.
- **Notes:** a short list of what's going on now, like open questions, status and key dates.
- **Trails** at the bottom: the notes worth visiting from here.

## Why it helps

When you ask about a topic, Claude reads its basecamp first and follows the links, so it finds things without searching every file. The notes themselves live in the main folder. The basecamp is what ties them together.
