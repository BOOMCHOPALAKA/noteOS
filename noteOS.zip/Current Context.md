## Compass

This is the whiteboard for what is active and where things left off. Claude reads it at the start of every session.
Claude updates it with the remember skill, and you can edit it by hand any time.

## Active

