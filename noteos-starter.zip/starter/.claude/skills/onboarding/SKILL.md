---
name: onboarding
description: Use when the About Me section in CLAUDE.md is empty or holds only the HTML comment, or when you type /onboarding to update your profile. Runs a short, friendly conversation that sets this folder up around you.
---

When this skill runs, start your reply with: Using onboarding skill

## What this is

The first conversation in this folder should feel like meeting someone, not filling in a form. By the end, Claude knows who you are and your first basecamp exists.

## When it runs

- **Automatically:** when About Me in `CLAUDE.md` is empty or holds only the HTML comment. Run this before anything else, whatever the person typed.
- **On request:** when the person types `/onboarding` or asks to update their profile. Skip the welcome. Say "Let's update your profile. I'll ask a few questions and change what's there." Then go to step 2, update what exists, and Close.
- **If About Me has real content** and nobody asked: do not run.

## Steps

### 1. Welcome

Your first reply is the welcome plus question 1. Make no tool calls before it. Say this, word for word:

> Hey! Welcome in. I'm really glad you're setting this up. This is the fun part. I'm going to ask you a few questions, one at a time, and build out your folder around your answers as we go. No wrong answers, and you can skip anything you want. First one: who are you, and what are you working on these days?

### 2. Ask the questions

One question per message. Between questions, react to the answer in the How Claude Talks style (see `CLAUDE.md`). Skip a question an answer already covers. Do not push on short answers. Aim for six questions. Before your first write, check the date with `date '+%Y-%m-%d %H:%M'` (Mac, Linux) or `Get-Date -Format "yyyy-MM-dd HH:mm"` (Windows). Use it anywhere you write a date.

1. **Who are you?** Their name, and what they do.
2. **What are you working on?** Active projects and areas. For each area, make one basecamp in `Map/` from `Templates/Basecamp.md`. Then add the active threads to `Current Context.md` under `## Active`, with today's date.
3. **Who are the key people?** Names to spell correctly, and who each person is to them.
4. **Which apps do you use day to day?** Write them down. Then say the connect skill can hook them up later, and nothing is connected yet.
5. **Paste something you wrote that sounds like you.** Save it in `Voice Log.md` under `## Samples` with a one-line note on what it shows. If they have nothing handy, say the voice skill will learn from their edits.
6. **How do you like answers?** Short or thorough, direct or gentle, anything to always or never do.

### 3. Build as you go

Write after each answer, not at the end. Say what you wrote in one clause ("I added that to Current Context").

When the questions are done, fill the **About Me** section of `CLAUDE.md`:

- Delete the HTML comment.
- Write a short paragraph on who they are and what they do.
- Add short lines for key people (with spellings), apps and how they like answers.
- Keep it lean. Detail lives in the basecamps.

Check that every basecamp links to `[[Current Context|Current Context]]` and that Current Context links to each basecamp.

### 4. Close

Sum up what now exists, not every file. Then:

- Tell them `/remember` saves a session and `/pickup` starts the next one.
- Point them to **Day 1, step 5** of the setup guide for what's next.

If this is Cowork or another tool that did not load `CLAUDE.md` on its own, ask: "One setup thing: can I save a note in this folder's instructions so I read CLAUDE.md first every time you open it?" On a yes, try to add `Read CLAUDE.md in this folder and follow it.` to the folder's instructions. If that doesn't stick, tell them to start each new session with that sentence.

Then the settings copy, in the Code tab only. Outside it, skip the copy and say the reminders are a Code tab extra. In the Code tab, if `.claude/settings.json` is missing, say: "Next I'll copy a small settings file into a hidden folder named `.claude`. It turns on two reminders. The app will ask you to approve it. Approve it." Copy `setup/mac/settings.json` on darwin or linux, or `setup/windows/settings.json` on win32. Make the `.claude` folder first if needed. Never overwrite an existing file. The reminders start next session.

Then say, word for word: "That's it, you're set up! From here on I live in this folder. Every note we make adds to what I know about your work, so it gets more useful the more you use it. Open Start Here.md any time you want the map."

Then ask, word for word: "Want a short tour of how all this works? It takes about ten minutes, and you can stop any time." On a yes, open `.claude/skills/tour/SKILL.md` and follow it. On a no, say they can ask for it any time.

## Hard rules

- One question at a time.
- If they want to skip, write "Set up manually." as the About Me text, delete the comment, do the Close settings copy if it applies, and stop.
- Do not assume any note app.
