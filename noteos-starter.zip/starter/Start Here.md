# Start Here

## Welcome

This folder is the start of your own AI thinking partner. It can be a business partner, a creative partner and a thinking partner, all in one place. It is a foundation, not a finished product. It grows with you as you use it.

## How it works

Claude lives in this folder. Every conversation can leave notes behind, and those notes are plain text files. Over time they become Claude's knowledge base about your work. You can open and read any of them in Obsidian (a free app for reading notes) or any text editor.

Links between notes do the organizing. A basecamp is a hub note in `Map/` for one topic, and it links to everything under that topic. Claude reads the basecamp first, so it finds things fast.

## Your first message

In Cowork or any other app, type this:

`Read CLAUDE.md in this folder and follow it.`

In the Code tab, `hi` works too.

## What's here

- `CLAUDE.md` holds Claude's instructions and what it knows about you.
- `Current Context.md` is a whiteboard of what is active right now.
- `Lessons Log.md` records corrections, so Claude learns from them.
- `Voice Log.md` holds samples of how you write.
- `Connections.md` lists the apps Claude can reach.
- `Map/` holds your basecamps.
- `Calendar/` holds your daily notes.
- `Downloads/` holds raw files, like PDFs and transcripts.
- `Templates/` holds the starting shape for new notes.
- `.claude/skills/` holds the playbooks Claude follows for one job each.

## Go slow

You do not need all of this on day one. The setup guide adds one habit a day, so you can start small and let it build.
